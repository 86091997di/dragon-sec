# 💣 Buffer Overflow – Vegeta Style

Quando Vegeta exagera no Kamehameha, ele destrói mais do que devia — como um buffer overflow.

## ⚠️ Atenção
Esse código é apenas para fins educacionais.

## 💡 Conceito
Buffer overflow acontece quando escrevemos mais dados do que a memória esperava, podendo sobrescrever partes críticas.

## 🧠 Tema
Excesso de poder = memória corrompida.
