// Vegeta exagerando no poder: Buffer Overflow

#include <stdio.h>
#include <string.h>

void explode() {
    printf("💥 Vegeta causou um Buffer Overflow!
");
}

void ataque(char *input) {
    char buffer[10];
    strcpy(buffer, input);  // Overflow se input > 10 chars
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        ataque(argv[1]);
    } else {
        printf("Uso: ./overflow [string]
");
    }
    return 0;
}
