# 🔥 Vazamento de Memória – Majin Buu Style

Majin Buu devora tudo e nunca libera nada — exatamente como esse script!

Esse exemplo simula um **vazamento de memória** para fins educativos.

## 🚨 Aviso
⚠️ Não execute por muito tempo: ele vai consumir muita RAM.

## 💡 Conceito
Um programa que aloca memória repetidamente e nunca libera causa lentidão, travamentos e vulnerabilidades de DoS.

## 🧠 Tema
Majin Buu devorando tudo sem parar = vazamento de memória!
