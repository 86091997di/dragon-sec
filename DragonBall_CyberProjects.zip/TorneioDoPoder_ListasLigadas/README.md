# 🕸️ Listas Ligadas – Torneio do Poder Style

Cada guerreiro está ligado ao próximo — como os nós de uma lista ligada.

## 🔗 Conceito
Uma lista ligada é uma estrutura onde cada item aponta para o próximo. Ideal para estruturas dinâmicas.

## 🧠 Tema
Guerreiros unidos como nós de memória!
