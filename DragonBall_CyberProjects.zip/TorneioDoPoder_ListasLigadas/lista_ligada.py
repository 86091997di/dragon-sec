# Lista ligada inspirada no Torneio do Poder

class Guerreiro:
    def __init__(self, nome):
        self.nome = nome
        self.proximo = None

g1 = Guerreiro("Goku")
g2 = Guerreiro("Vegeta")
g3 = Guerreiro("Android 17")
g4 = Guerreiro("Freeza")

g1.proximo = g2
g2.proximo = g3
g3.proximo = g4

atual = g1
while atual:
    print(f"Guerreiro: {atual.nome}")
    atual = atual.proximo
