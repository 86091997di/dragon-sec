# 💥 Ataque DoS – Goku Style

Goku lança um Kamehameha infinito contra um oponente fraco — assim como esse script simula um ataque de negação de serviço (DoS).

## ⚠️ Uso Educativo
Este código é apenas para fins de estudo e deve ser executado apenas em ambientes de teste.

## 🎯 Conceito
Ataques DoS esgotam recursos de um servidor, impedindo que ele responda a usuários reais.

## 🧠 Tema
Kamehameha infinito = ataque DoS.
